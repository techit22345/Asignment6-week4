window.onresize = displayWindowSize;
window.onload = displayWindowSize;

function displayWindowSize(){
	myWidth = window.innerWidth;
	myHeight = window.innerHeight;
	document.getElementById("width").innerHTML = "Width: " + myWidth;
	document.getElementById("height").innerHTML = "Height: " + myHeight;
}

document.getElementById("location").innerHTML += window.location;

