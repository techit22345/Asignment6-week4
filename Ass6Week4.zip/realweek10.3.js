function mouseOver(){
		document.getElementById("over-out-event").innerHTML = "On Mouse Over";
}

function mouseOut(){
	document.getElementById("over-out-event").innerHTML = "On Mouse Out";
}

function mouseDown(){
	document.getElementById("up-down-event").innerHTML = "On Mouse Down";
}

function mouseUp(){
	document.getElementById("up-down-event").innerHTML = "On Mouse Up";
}

function doubleClick(){
	document.getElementById("double-click-event").innerHTML = "On Mouse Up";
}